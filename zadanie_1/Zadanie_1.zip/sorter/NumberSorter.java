package sorter;

import java.util.List;

public interface NumberSorter {
    List<Double> sortData(List<Double> input);
}
